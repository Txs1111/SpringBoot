package com.T_Lyon.qimo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QimoApplication {

    public static void main(String[] args) {
        SpringApplication.run(QimoApplication.class, args);
    }

}
