package com.T_Lyon.Demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellowroldApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellowroldApplication.class, args);
	}

}
