package com.T_Lyon.Demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellowroldApplicationTests {

	@Test
	void contextLoads() {
	}

}
