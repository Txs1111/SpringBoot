package com.T_Lyon.qimo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QimoApplicationTests {

    @Test
    void contextLoads() {
    }

}
